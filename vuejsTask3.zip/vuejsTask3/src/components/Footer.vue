<template>
    <footer>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-1 md:gap-5 bg-slate-100 p-12 w-full mt-28">
        <div class="md:p-32 p-1">
          <div class="flex gap-2 mb-5">
            <h1 class="text-black font-regular text-5xl fonta-lato">Need a project?</h1>
          </div>
          <p class="text-black fonta-lato leading-loose tracking-wide w-full md:w-[80%]">(239) 555-0108 <br><span class="text-secondary">tanya.hill@example.com</span></p>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 justify-center gap-12 text-black p-32">
          <div>
            <div class="flex flex-col gap-4">
              <a href="#" class="hover:underline">Facebook</a>
              <a href="#" class="hover:underline">Instagram</a>
              <a href="#" class="hover:underline">Dribbble</a>
              <a href="#" class="hover:underline">Linkedin</a>
            </div>
          </div>
          <div>
            <div class="flex flex-col gap-6">
              <p class="text-white">1</p>
              <p class="md:text-md font-regular text-left text-black mt-8 tracking-wider fonta-lato">
          &copy; Copyright Manifest Theme. Allrights reserved
        </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </template>