<template>
  <router-view />
 </template>
 
 <script setup>
 
 </script>
 
 <style >
/* Add Lato font to the styles */
@import url('https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap');

/* Apply the Lato font */
.font-lato {
  font-family: 'Lato', sans-serif;
}
</style>