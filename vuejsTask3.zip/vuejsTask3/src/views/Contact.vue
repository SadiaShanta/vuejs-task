<template>
    <div class="p-8 pb-0">
    <h1 class="text-4xl font-bold mb-4 text-black-500">Contact</h1>
  </div>
</template>