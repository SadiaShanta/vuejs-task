<template>
    <div class="p-8 pb-0">
    <h1 class="text-4xl font-bold mb-40 text-black-500">Works</h1>
  </div>
</template>